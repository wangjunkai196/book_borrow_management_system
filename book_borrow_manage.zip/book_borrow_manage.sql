/*
Navicat MySQL Data Transfer

Source Server         : QHC
Source Server Version : 50621
Source Host           : 127.0.0.1:3306
Source Database       : biyesheji

Target Server Type    : MYSQL
Target Server Version : 50621
File Encoding         : 65001

Date: 2017-06-05 10:58:11
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for admin
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `Adminid` int(11) NOT NULL AUTO_INCREMENT,
  `Adminname` varchar(255) NOT NULL,
  `Adminpassword` varchar(255) NOT NULL,
  `Adminsrtype` varchar(255) NOT NULL,
  `Telephone` varchar(255) NOT NULL,
  PRIMARY KEY (`Adminid`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of admin
-- ----------------------------
INSERT INTO `admin` VALUES ('2', '2', '2', '体育类', '18438671233');
INSERT INTO `admin` VALUES ('3', '3', '3', '土木类', '13526470253');
INSERT INTO `admin` VALUES ('4', '4', '4', '服装类', '16751255553');
INSERT INTO `admin` VALUES ('5', '5', '5', '计算机类', '12345678903');
INSERT INTO `admin` VALUES ('6', '6', '6', '金融类', '13232323233');
INSERT INTO `admin` VALUES ('12', '覃华财', '123456', '超级管理员', '18438671233');
INSERT INTO `admin` VALUES ('13', '8', '8', '农业类', '00000000000');
INSERT INTO `admin` VALUES ('28', '1', '1', '其他类', '13568689766');

-- ----------------------------
-- Table structure for announcement
-- ----------------------------
DROP TABLE IF EXISTS `announcement`;
CREATE TABLE `announcement` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Announcement` varchar(255) DEFAULT NULL,
  `Time` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of announcement
-- ----------------------------
INSERT INTO `announcement` VALUES ('1', '招聘管理员', '2017-04-16 17:05:21');
INSERT INTO `announcement` VALUES ('2', '招聘管理员', '2017-04-16 17:06:09');
INSERT INTO `announcement` VALUES ('3', '已发布最新科研信息', '2017-04-17 09:15:36');
INSERT INTO `announcement` VALUES ('4', '我是田哥', '2017-04-18 09:55:23');
INSERT INTO `announcement` VALUES ('5', '我是公告', '2017-04-20 15:45:16');
INSERT INTO `announcement` VALUES ('6', ' 公告测试', '2017-04-21 11:45:21');
INSERT INTO `announcement` VALUES ('7', '我是王博', '2017-04-21 11:47:48');
INSERT INTO `announcement` VALUES ('8', '测试', '2017-04-27 15:58:01');
INSERT INTO `announcement` VALUES ('9', 'session测试', '2017-05-02 19:25:14');
INSERT INTO `announcement` VALUES ('10', '再来', '2017-05-02 20:17:36');
INSERT INTO `announcement` VALUES ('11', '我的公告', '2017-05-03 11:09:00');
INSERT INTO `announcement` VALUES ('12', '', '2017-05-03 11:10:15');
INSERT INTO `announcement` VALUES ('13', '家里发生口角法律框架是法律解释了', '2017-05-03 11:10:22');
INSERT INTO `announcement` VALUES ('14', '菜', '2017-05-03 11:20:53');
INSERT INTO `announcement` VALUES ('15', '0', '2017-05-03 11:21:18');
INSERT INTO `announcement` VALUES ('16', '0', '2017-05-03 11:22:32');
INSERT INTO `announcement` VALUES ('17', '。', '2017-05-03 11:22:46');
INSERT INTO `announcement` VALUES ('18', '车市', '2017-05-03 11:35:07');
INSERT INTO `announcement` VALUES ('19', '公告', '2017-05-03 20:59:26');

-- ----------------------------
-- Table structure for journal
-- ----------------------------
DROP TABLE IF EXISTS `journal`;
CREATE TABLE `journal` (
  `Journalid` int(11) NOT NULL AUTO_INCREMENT,
  `Userid` int(11) NOT NULL,
  `Journal` varchar(255) DEFAULT NULL,
  `Journal_time` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Journalid`)
) ENGINE=InnoDB AUTO_INCREMENT=196 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of journal
-- ----------------------------
INSERT INTO `journal` VALUES ('1', '1', '测试', '2017-04-08 21:05:02');
INSERT INTO `journal` VALUES ('2', '9', 'http://localhost:8080/Biyesheji/jsp/updateusers.jsp', '2017-04-08 21:37:55');
INSERT INTO `journal` VALUES ('3', '9', 'http://localhost:8080/Biyesheji/jsp/updateusers.jsp', '2017-04-08 21:38:02');
INSERT INTO `journal` VALUES ('4', '5', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-04-08 21:38:18');
INSERT INTO `journal` VALUES ('5', '9', 'http://localhost:8080/Biyesheji/jsp/uptext.jsp', '2017-04-08 21:40:01');
INSERT INTO `journal` VALUES ('6', '9', 'http://localhost:8080/Biyesheji/jsp/users.jsp', '2017-04-08 21:40:02');
INSERT INTO `journal` VALUES ('7', '9', 'http://localhost:8080/Biyesheji/jsp/users.jsp', '2017-04-08 21:40:02');
INSERT INTO `journal` VALUES ('8', '1', 'http://localhost:8080/Biyesheji/jsp/users.jsp', '2017-04-08 21:41:21');
INSERT INTO `journal` VALUES ('9', '5', 'http://localhost:8080/Biyesheji/jsp/users.jsp', '2017-04-08 22:01:01');
INSERT INTO `journal` VALUES ('10', '5', 'http://localhost:8080/Biyesheji/jsp/users.jsp', '2017-04-08 22:01:06');
INSERT INTO `journal` VALUES ('11', '5', 'http://localhost:8080/Biyesheji/jsp/users.jsp', '2017-04-08 22:01:18');
INSERT INTO `journal` VALUES ('12', '1', 'http://localhost:8080/Biyesheji/jsp/uptext.jsp', '2017-04-10 13:26:31');
INSERT INTO `journal` VALUES ('13', '1', 'http://localhost:8080/Biyesheji/jsp/uptext.jsp', '2017-04-10 13:26:56');
INSERT INTO `journal` VALUES ('14', '1', 'http://localhost:8080/Biyesheji/jsp/uptext.jsp', '2017-04-10 13:27:04');
INSERT INTO `journal` VALUES ('15', '1', 'http://localhost:8080/Biyesheji/jsp/uptext.jsp', '2017-04-10 13:27:32');
INSERT INTO `journal` VALUES ('16', '1', 'http://localhost:8080/Biyesheji/jsp/uptext.jsp', '2017-04-10 13:27:45');
INSERT INTO `journal` VALUES ('17', '1', 'http://localhost:8080/Biyesheji/jsp/uptext.jsp', '2017-04-10 13:28:14');
INSERT INTO `journal` VALUES ('18', '5', 'http://localhost:8080/Biyesheji/jsp/users.jsp', '2017-04-10 14:25:56');
INSERT INTO `journal` VALUES ('19', '4', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-04-10 14:26:05');
INSERT INTO `journal` VALUES ('20', '4', 'http://localhost:8080/Biyesheji/jsp/uptext.jsp', '2017-04-10 14:26:27');
INSERT INTO `journal` VALUES ('21', '1', 'http://localhost:8080/Biyesheji/jsp/uptext.jsp', '2017-04-11 17:40:13');
INSERT INTO `journal` VALUES ('22', '1', 'http://localhost:8080/Biyesheji/jsp/uptext.jsp', '2017-04-11 17:42:19');
INSERT INTO `journal` VALUES ('23', '1', 'http://localhost:8080/Biyesheji/jsp/uptext.jsp', '2017-04-11 17:42:31');
INSERT INTO `journal` VALUES ('24', '1', 'http://localhost:8080/Biyesheji/jsp/uptext.jsp', '2017-04-11 18:27:13');
INSERT INTO `journal` VALUES ('25', '1', 'http://localhost:8080/Biyesheji/jsp/uptext.jsp', '2017-04-11 18:42:02');
INSERT INTO `journal` VALUES ('26', '1', 'http://localhost:8080/Biyesheji/jsp/uptext.jsp', '2017-04-11 18:43:43');
INSERT INTO `journal` VALUES ('27', '1', 'http://localhost:8080/Biyesheji/jsp/uptext.jsp', '2017-04-11 18:43:58');
INSERT INTO `journal` VALUES ('28', '1', 'http://localhost:8080/Biyesheji/jsp/uptext.jsp', '2017-04-11 18:45:53');
INSERT INTO `journal` VALUES ('29', '7', 'http://localhost:8080/Biyesheji/jsp/users.jsp', '2017-04-11 20:48:14');
INSERT INTO `journal` VALUES ('30', '1', 'http://localhost:8080/Biyesheji/jsp/users.jsp', '2017-04-11 20:48:53');
INSERT INTO `journal` VALUES ('31', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-04-11 20:50:54');
INSERT INTO `journal` VALUES ('32', '5', 'http://localhost:8080/Biyesheji/jsp/users.jsp', '2017-04-11 20:51:09');
INSERT INTO `journal` VALUES ('33', '4', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-04-11 20:51:21');
INSERT INTO `journal` VALUES ('34', '4', 'http://localhost:8080/Biyesheji/jsp/uptext.jsp', '2017-04-11 20:51:38');
INSERT INTO `journal` VALUES ('36', '4', 'http://localhost:8080/Biyesheji/jsp/uptext.jsp', '2017-04-11 20:53:51');
INSERT INTO `journal` VALUES ('37', '1', 'http://localhost:8080/Biyesheji/jsp/users.jsp', '2017-04-12 11:47:02');
INSERT INTO `journal` VALUES ('38', '2', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-04-12 11:47:25');
INSERT INTO `journal` VALUES ('39', '2', 'http://localhost:8080/Biyesheji/jsp/uptext.jsp', '2017-04-12 11:47:36');
INSERT INTO `journal` VALUES ('40', '3', 'http://localhost:8081/Biyesheji/jsp/up.jsp', '2017-04-12 11:54:50');
INSERT INTO `journal` VALUES ('41', '3', 'http://localhost:8081/Biyesheji/jsp/uptext.jsp', '2017-04-12 11:55:06');
INSERT INTO `journal` VALUES ('42', '9', 'http://localhost:8080/Biyesheji/jsp/users.jsp', '2017-04-12 12:07:56');
INSERT INTO `journal` VALUES ('43', '10', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-04-12 12:08:12');
INSERT INTO `journal` VALUES ('44', '10', 'http://localhost:8080/Biyesheji/jsp/uptext.jsp', '2017-04-12 12:08:21');
INSERT INTO `journal` VALUES ('46', '6', 'http://localhost:8080/Biyesheji/jsp/users.jsp', '2017-04-15 08:07:41');
INSERT INTO `journal` VALUES ('47', '6', 'http://localhost:8080/Biyesheji/jsp/updateusers.jsp', '2017-04-15 08:13:06');
INSERT INTO `journal` VALUES ('48', '5', 'http://localhost:8080/Biyesheji/jsp/users.jsp', '2017-04-15 08:14:44');
INSERT INTO `journal` VALUES ('49', '5', 'http://localhost:8080/Biyesheji/jsp/users.jsp', '2017-04-15 08:17:10');
INSERT INTO `journal` VALUES ('50', '9', 'http://localhost:8080/Biyesheji/jsp/users.jsp', '2017-04-15 18:11:24');
INSERT INTO `journal` VALUES ('51', '9', 'http://localhost:8080/Biyesheji/jsp/users.jsp', '2017-04-15 18:14:43');
INSERT INTO `journal` VALUES ('52', '9', 'http://localhost:8080/Biyesheji/jsp/users.jsp', '2017-04-15 18:19:20');
INSERT INTO `journal` VALUES ('53', '9', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-04-15 18:19:38');
INSERT INTO `journal` VALUES ('54', '9', 'http://localhost:8080/Biyesheji/jsp/uptext.jsp', '2017-04-15 18:20:21');
INSERT INTO `journal` VALUES ('55', '9', 'http://localhost:8080/Biyesheji/jsp/uptext.jsp', '2017-04-15 18:21:45');
INSERT INTO `journal` VALUES ('56', '1', 'http://localhost:8080/Biyesheji/jsp/users.jsp', '2017-04-16 09:32:19');
INSERT INTO `journal` VALUES ('57', '1', 'http://localhost:8080/Biyesheji/jsp/users.jsp', '2017-04-16 09:32:22');
INSERT INTO `journal` VALUES ('58', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-04-16 09:33:49');
INSERT INTO `journal` VALUES ('59', '1', 'http://localhost:8080/Biyesheji/jsp/users.jsp', '2017-04-16 09:41:46');
INSERT INTO `journal` VALUES ('60', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-04-16 09:42:02');
INSERT INTO `journal` VALUES ('61', '1', 'http://localhost:8080/Biyesheji/jsp/users.jsp', '2017-04-16 10:02:42');
INSERT INTO `journal` VALUES ('62', '1', 'http://localhost:8080/Biyesheji/jsp/users.jsp', '2017-04-16 10:02:45');
INSERT INTO `journal` VALUES ('63', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-04-16 10:02:53');
INSERT INTO `journal` VALUES ('64', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-04-16 10:03:01');
INSERT INTO `journal` VALUES ('65', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-04-16 10:03:18');
INSERT INTO `journal` VALUES ('66', '1', 'http://localhost:8080/Biyesheji/jsp/updateusers.jsp', '2017-04-16 10:16:15');
INSERT INTO `journal` VALUES ('67', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-04-16 10:57:59');
INSERT INTO `journal` VALUES ('68', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-04-16 10:58:11');
INSERT INTO `journal` VALUES ('69', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-04-16 11:02:56');
INSERT INTO `journal` VALUES ('70', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-04-16 11:03:03');
INSERT INTO `journal` VALUES ('71', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-04-16 11:03:25');
INSERT INTO `journal` VALUES ('72', '9', 'http://localhost:8080/Biyesheji/jsp/users.jsp', '2017-04-16 11:10:16');
INSERT INTO `journal` VALUES ('73', '9', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-04-16 11:17:28');
INSERT INTO `journal` VALUES ('74', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-04-16 11:19:30');
INSERT INTO `journal` VALUES ('75', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-04-16 11:19:37');
INSERT INTO `journal` VALUES ('76', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-04-16 11:19:50');
INSERT INTO `journal` VALUES ('77', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-04-16 11:21:19');
INSERT INTO `journal` VALUES ('78', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-04-16 11:21:52');
INSERT INTO `journal` VALUES ('79', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-04-16 16:32:10');
INSERT INTO `journal` VALUES ('80', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-04-16 16:32:18');
INSERT INTO `journal` VALUES ('81', '1', 'http://localhost:8080/Biyesheji/jsp/users.jsp', '2017-04-17 09:50:21');
INSERT INTO `journal` VALUES ('82', '1', 'http://localhost:8080/Biyesheji/jsp/users.jsp', '2017-04-18 09:44:48');
INSERT INTO `journal` VALUES ('83', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-04-18 09:45:19');
INSERT INTO `journal` VALUES ('84', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-04-18 09:45:32');
INSERT INTO `journal` VALUES ('85', '5', 'http://localhost:8080/Biyesheji/jsp/users.jsp', '2017-04-20 15:54:29');
INSERT INTO `journal` VALUES ('86', '6', 'http://localhost:8080/Biyesheji/jsp/users.jsp', '2017-04-21 13:54:20');
INSERT INTO `journal` VALUES ('87', '6', 'http://localhost:8080/Biyesheji/jsp/users.jsp', '2017-04-21 13:55:58');
INSERT INTO `journal` VALUES ('88', '1', 'http://localhost:8080/Biyesheji/jsp/users.jsp', '2017-04-22 16:29:32');
INSERT INTO `journal` VALUES ('89', '1', 'http://localhost:8080/Biyesheji/jsp/users.jsp', '2017-04-22 16:38:00');
INSERT INTO `journal` VALUES ('90', '1', 'http://localhost:8080/Biyesheji/jsp/updateusers.jsp', '2017-04-22 16:38:12');
INSERT INTO `journal` VALUES ('91', '1', 'http://localhost:8080/Biyesheji/jsp/users.jsp', '2017-04-22 16:38:21');
INSERT INTO `journal` VALUES ('92', '1', 'http://localhost:8080/Biyesheji/jsp/users.jsp', '2017-04-22 16:38:38');
INSERT INTO `journal` VALUES ('93', '1', 'http://localhost:8080/Biyesheji/jsp/users.jsp', '2017-04-22 16:38:43');
INSERT INTO `journal` VALUES ('94', '1', 'http://localhost:8080/Biyesheji/jsp/users.jsp', '2017-04-22 16:49:04');
INSERT INTO `journal` VALUES ('95', '1', 'http://localhost:8080/Biyesheji/jsp/updateusers.jsp', '2017-04-22 16:49:13');
INSERT INTO `journal` VALUES ('96', '1', 'http://localhost:8080/Biyesheji/jsp/users.jsp', '2017-04-22 16:54:12');
INSERT INTO `journal` VALUES ('97', '1', 'http://localhost:8080/Biyesheji/jsp/updateusers.jsp', '2017-04-22 16:54:23');
INSERT INTO `journal` VALUES ('98', '1', 'http://localhost:8080/Biyesheji/jsp/users.jsp', '2017-04-22 16:54:33');
INSERT INTO `journal` VALUES ('99', '1', 'http://localhost:8080/Biyesheji/jsp/updateusers.jsp', '2017-04-22 17:01:38');
INSERT INTO `journal` VALUES ('100', '1', 'http://localhost:8080/Biyesheji/jsp/updateusers.jsp', '2017-04-22 17:07:03');
INSERT INTO `journal` VALUES ('101', '1', 'http://localhost:8080/Biyesheji/jsp/updateusers.jsp', '2017-04-22 17:10:33');
INSERT INTO `journal` VALUES ('102', '1', 'http://localhost:8080/Biyesheji/jsp/users.jsp', '2017-04-22 17:10:41');
INSERT INTO `journal` VALUES ('103', '1', 'http://localhost:8080/Biyesheji/jsp/updateusers.jsp', '2017-04-22 17:10:46');
INSERT INTO `journal` VALUES ('104', '1', 'http://localhost:8080/Biyesheji/jsp/updateusers.jsp', '2017-04-22 17:12:25');
INSERT INTO `journal` VALUES ('105', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-04-22 17:22:12');
INSERT INTO `journal` VALUES ('106', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-04-22 17:26:51');
INSERT INTO `journal` VALUES ('107', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-04-22 17:27:02');
INSERT INTO `journal` VALUES ('108', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-04-22 17:29:12');
INSERT INTO `journal` VALUES ('109', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-04-22 17:29:32');
INSERT INTO `journal` VALUES ('110', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-04-22 17:30:46');
INSERT INTO `journal` VALUES ('111', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-04-22 17:30:53');
INSERT INTO `journal` VALUES ('112', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-04-22 17:31:58');
INSERT INTO `journal` VALUES ('113', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-04-22 17:32:03');
INSERT INTO `journal` VALUES ('114', '7', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-04-23 09:43:30');
INSERT INTO `journal` VALUES ('115', '7', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-04-23 09:44:28');
INSERT INTO `journal` VALUES ('116', '7', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-04-23 09:44:34');
INSERT INTO `journal` VALUES ('117', '8', 'http://localhost:8080/Biyesheji/jsp/users.jsp', '2017-04-23 10:11:09');
INSERT INTO `journal` VALUES ('118', '7', 'http://localhost:8080/Biyesheji/jsp/users.jsp', '2017-04-23 10:29:38');
INSERT INTO `journal` VALUES ('119', '7', 'http://localhost:8080/Biyesheji/jsp/updateusers.jsp', '2017-04-23 10:30:04');
INSERT INTO `journal` VALUES ('120', '7', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-04-23 10:30:19');
INSERT INTO `journal` VALUES ('121', '7', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-04-23 10:31:40');
INSERT INTO `journal` VALUES ('122', '7', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-04-23 10:31:44');
INSERT INTO `journal` VALUES ('123', '1', 'http://127.0.0.1:8080/Biyesheji/jsp/users.jsp', '2017-04-26 15:17:08');
INSERT INTO `journal` VALUES ('124', '1', 'http://127.0.0.1:8080/Biyesheji/jsp/users.jsp', '2017-04-26 15:18:04');
INSERT INTO `journal` VALUES ('125', '1', 'http://127.0.0.1:8080/Biyesheji/jsp/users.jsp', '2017-04-26 15:18:22');
INSERT INTO `journal` VALUES ('126', '1', 'http://127.0.0.1:8080/Biyesheji/jsp/users.jsp', '2017-04-26 15:20:42');
INSERT INTO `journal` VALUES ('127', '1', 'http://127.0.0.1:8080/Biyesheji/jsp/users.jsp', '2017-04-26 15:23:59');
INSERT INTO `journal` VALUES ('128', '1', 'http://127.0.0.1:8080/Biyesheji/jsp/users.jsp', '2017-04-26 15:26:22');
INSERT INTO `journal` VALUES ('129', '1', 'http://127.0.0.1:8080/Biyesheji/jsp/users.jsp', '2017-04-26 15:27:18');
INSERT INTO `journal` VALUES ('130', '1', 'http://127.0.0.1:8080/Biyesheji/jsp/users.jsp', '2017-04-26 15:27:37');
INSERT INTO `journal` VALUES ('131', '1', 'http://127.0.0.1:8080/Biyesheji/jsp/users.jsp', '2017-04-26 15:39:36');
INSERT INTO `journal` VALUES ('132', '1', 'http://127.0.0.1:8080/Biyesheji/jsp/users.jsp', '2017-04-26 15:41:29');
INSERT INTO `journal` VALUES ('133', '1', 'http://127.0.0.1:8080/Biyesheji/jsp/users.jsp', '2017-04-26 15:41:54');
INSERT INTO `journal` VALUES ('134', '1', 'http://127.0.0.1:8080/Biyesheji/jsp/users.jsp', '2017-04-26 15:44:15');
INSERT INTO `journal` VALUES ('135', '1', 'http://127.0.0.1:8080/Biyesheji/jsp/users.jsp', '2017-04-26 15:46:13');
INSERT INTO `journal` VALUES ('136', '1', 'http://127.0.0.1:8080/Biyesheji/jsp/users.jsp', '2017-04-26 15:47:13');
INSERT INTO `journal` VALUES ('137', '1', 'http://127.0.0.1:8080/Biyesheji/jsp/users.jsp', '2017-04-26 15:47:35');
INSERT INTO `journal` VALUES ('138', '1', 'http://127.0.0.1:8080/Biyesheji/jsp/users.jsp', '2017-04-26 15:48:05');
INSERT INTO `journal` VALUES ('139', '1', 'http://127.0.0.1:8080/Biyesheji/jsp/users.jsp', '2017-04-26 15:49:11');
INSERT INTO `journal` VALUES ('140', '1', 'http://127.0.0.1:8080/Biyesheji/jsp/users.jsp', '2017-04-26 15:51:34');
INSERT INTO `journal` VALUES ('141', '1', 'http://localhost:8080/Biyesheji/jsp/users.jsp', '2017-04-26 17:04:42');
INSERT INTO `journal` VALUES ('142', '1', 'http://localhost:8080/Biyesheji/jsp/users.jsp', '2017-04-26 17:46:02');
INSERT INTO `journal` VALUES ('143', '1', 'http://localhost:8080/Biyesheji/jsp/users.jsp', '2017-04-26 17:46:08');
INSERT INTO `journal` VALUES ('144', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-04-26 17:46:15');
INSERT INTO `journal` VALUES ('145', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-04-26 17:46:29');
INSERT INTO `journal` VALUES ('146', '1', 'http://127.0.0.1:8080/Biyesheji/jsp/up.jsp', '2017-04-27 15:59:56');
INSERT INTO `journal` VALUES ('147', '1', 'http://127.0.0.1:8080/Biyesheji/jsp/up.jsp', '2017-04-27 16:01:25');
INSERT INTO `journal` VALUES ('148', '1', 'http://127.0.0.1:8080/Biyesheji/jsp/up.jsp', '2017-04-27 16:01:59');
INSERT INTO `journal` VALUES ('149', '1', 'http://127.0.0.1:8080/Biyesheji/jsp/up.jsp', '2017-04-27 16:02:08');
INSERT INTO `journal` VALUES ('150', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-05-02 09:24:05');
INSERT INTO `journal` VALUES ('151', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-05-02 09:42:34');
INSERT INTO `journal` VALUES ('152', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-05-02 09:51:40');
INSERT INTO `journal` VALUES ('153', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-05-02 09:54:44');
INSERT INTO `journal` VALUES ('154', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-05-02 10:01:38');
INSERT INTO `journal` VALUES ('155', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-05-02 10:03:24');
INSERT INTO `journal` VALUES ('156', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-05-02 10:06:51');
INSERT INTO `journal` VALUES ('157', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-05-02 10:09:29');
INSERT INTO `journal` VALUES ('158', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-05-02 10:45:14');
INSERT INTO `journal` VALUES ('159', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-05-02 10:46:52');
INSERT INTO `journal` VALUES ('160', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-05-02 10:51:17');
INSERT INTO `journal` VALUES ('161', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-05-02 10:59:36');
INSERT INTO `journal` VALUES ('162', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-05-02 10:59:49');
INSERT INTO `journal` VALUES ('163', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-05-02 11:10:28');
INSERT INTO `journal` VALUES ('164', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-05-02 11:10:39');
INSERT INTO `journal` VALUES ('165', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-05-02 11:12:09');
INSERT INTO `journal` VALUES ('166', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-05-02 11:14:08');
INSERT INTO `journal` VALUES ('167', '14', 'http://localhost:8080/Biyesheji/jsp/updateusers.jsp', '2017-05-02 18:58:30');
INSERT INTO `journal` VALUES ('168', '1', 'http://localhost:8080/Biyesheji/jsp/users.jsp', '2017-05-03 13:25:08');
INSERT INTO `journal` VALUES ('169', '9', 'http://localhost:8080/Biyesheji/jsp/updateusers.jsp', '2017-05-03 13:30:05');
INSERT INTO `journal` VALUES ('170', '1', 'http://localhost:8080/Biyesheji/jsp/users.jsp', '2017-05-03 13:40:32');
INSERT INTO `journal` VALUES ('171', '1', 'http://localhost:8080/Biyesheji//jsp/users.jsp', '2017-05-03 13:40:56');
INSERT INTO `journal` VALUES ('175', '1', 'http://localhost:8080/Biyesheji/jsp/updateusers.jsp', '2017-05-03 14:44:51');
INSERT INTO `journal` VALUES ('176', '1', 'http://localhost:8080/Biyesheji/jsp/updateusers.jsp', '2017-05-03 15:02:53');
INSERT INTO `journal` VALUES ('177', '1', 'http://localhost:8080/Biyesheji/jsp/updateusers.jsp', '2017-05-03 15:17:27');
INSERT INTO `journal` VALUES ('178', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-05-03 15:17:44');
INSERT INTO `journal` VALUES ('179', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-05-03 15:21:17');
INSERT INTO `journal` VALUES ('180', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-05-03 15:21:25');
INSERT INTO `journal` VALUES ('181', '1', 'http://localhost:8080/Biyesheji/jsp/updateusers.jsp', '2017-05-03 15:24:37');
INSERT INTO `journal` VALUES ('182', '1', 'http://localhost:8080/Biyesheji/jsp/updateusers.jsp', '2017-05-03 15:24:37');
INSERT INTO `journal` VALUES ('183', '1', 'http://localhost:8080/Biyesheji/jsp/updateusers.jsp', '2017-05-03 15:25:39');
INSERT INTO `journal` VALUES ('184', '1', 'http://localhost:8080/Biyesheji/jsp/updateusers.jsp', '2017-05-03 21:02:10');
INSERT INTO `journal` VALUES ('185', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-05-03 21:02:29');
INSERT INTO `journal` VALUES ('186', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-05-03 21:02:33');
INSERT INTO `journal` VALUES ('187', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-05-05 19:27:04');
INSERT INTO `journal` VALUES ('188', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-05-05 19:27:22');
INSERT INTO `journal` VALUES ('189', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-05-07 16:20:47');
INSERT INTO `journal` VALUES ('190', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-05-07 16:21:43');
INSERT INTO `journal` VALUES ('191', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-05-16 12:31:08');
INSERT INTO `journal` VALUES ('192', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-05-16 12:31:20');
INSERT INTO `journal` VALUES ('193', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-05-16 12:31:28');
INSERT INTO `journal` VALUES ('194', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-05-16 12:31:52');
INSERT INTO `journal` VALUES ('195', '1', 'http://localhost:8080/Biyesheji/jsp/up.jsp', '2017-05-31 16:00:55');

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `Userid` int(11) NOT NULL AUTO_INCREMENT,
  `Username` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Degree` varchar(255) DEFAULT NULL,
  `Degree_unit` varchar(255) DEFAULT NULL,
  `Degree_start` date DEFAULT NULL,
  `Degree_end` date DEFAULT NULL,
  `Degree_najor` varchar(255) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Head` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Userid`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES ('1', '1', '1', '1', '1', '0001-01-01', '0001-01-01', '1', '11111', 'IMG_0043.JPG');
INSERT INTO `users` VALUES ('5', '4', '4', '4', '4', '0004-04-01', '0004-04-01', '4', '4', 'IMG_0033.JPG');
INSERT INTO `users` VALUES ('6', '6', '6', '6', '6', '0006-06-01', '0006-06-01', '6', '6', 'IMG_0347.JPG');
INSERT INTO `users` VALUES ('7', '7', '7', '7', '7', '0007-07-01', '0007-07-01', '7', '7', 'IMG_0037.JPG');
INSERT INTO `users` VALUES ('8', '9', '9', '9', '9', '0009-09-01', '0009-09-01', '9', '9', 'IMG_0020.JPG');
INSERT INTO `users` VALUES ('9', '123', '123', '1', '1', '0001-01-01', '0001-01-01', '1', '1', null);
INSERT INTO `users` VALUES ('10', '3333', '3333', '3', '33', '0005-09-01', '0003-03-01', '3', '3', 'IMG_0020.JPG');
INSERT INTO `users` VALUES ('11', '44444444', '444444', '0', '0', '0002-12-01', '0002-12-01', '0', '0', null);
INSERT INTO `users` VALUES ('15', '测试3', '3', '3', '3', '0003-03-01', '0003-03-01', '3', '3', null);

-- ----------------------------
-- Table structure for users_sr
-- ----------------------------
DROP TABLE IF EXISTS `users_sr`;
CREATE TABLE `users_sr` (
  `Srid` int(11) NOT NULL AUTO_INCREMENT,
  `Userid` int(11) NOT NULL,
  `Srname` varchar(255) NOT NULL,
  `Srunit` varchar(255) NOT NULL,
  `Srlist` varchar(255) NOT NULL,
  `Srtime` varchar(255) DEFAULT NULL,
  `Srcheck` varchar(255) DEFAULT '待审核',
  `Sradopt` varchar(255) DEFAULT NULL,
  `Srtype` varchar(255) NOT NULL,
  `Reportname` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Srid`),
  KEY `FK_Userid` (`Userid`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of users_sr
-- ----------------------------
INSERT INTO `users_sr` VALUES ('11', '1', '2', '2', '2', '2', '已审核', '未通过', '计算机类', null);
INSERT INTO `users_sr` VALUES ('14', '6', '44', '4', '4', '44', '已审核', '通过', '金融类', null);
INSERT INTO `users_sr` VALUES ('22', '1', '33', '33', '33', '33', '已审核', '通过', '农业类', null);
INSERT INTO `users_sr` VALUES ('24', '1', '11', '11', '11', '11', '已审核', '通过', '土木类', null);
INSERT INTO `users_sr` VALUES ('25', '1', '22', '22', '22', '22', '已审核', '通过', '其他类', 'IMG_0020.JPG');
INSERT INTO `users_sr` VALUES ('27', '5', '123', '123', '123', '123', '已审核', '通过', '其他类', 'IMG_0020.JPG');
INSERT INTO `users_sr` VALUES ('28', '5', '321', '321', '321', '321', '已审核', '通过', '体育类', '500.jpg');
INSERT INTO `users_sr` VALUES ('29', '1', '6666', '6666', '6666', '6666', '已审核', '通过', '计算机类', 'IMG_0059.JPG');
INSERT INTO `users_sr` VALUES ('30', '1', '测试', '测试', '测试', '测试', '已审核', '通过', '服装类', 'IMG_0033.JPG');
INSERT INTO `users_sr` VALUES ('31', '5', '科研', '科研', '科研', '科研', '已审核', '通过', '体育类', 'IMG_0037.JPG');
INSERT INTO `users_sr` VALUES ('32', '1', '信息', '信息', '信息', '信息', '已审核', '通过', '计算机类', 'IMG_0038.JPG');
INSERT INTO `users_sr` VALUES ('33', '7', '教育科研', '教育', '张三', '20071202', '已审核', '通过', '其他类', 'IMG_0038.JPG');
INSERT INTO `users_sr` VALUES ('34', '7', '7', '7', '7', '7', '已审核', '通过', '计算机类', null);
INSERT INTO `users_sr` VALUES ('35', '7', '9', '9', '9', '9', '已审核', '通过', '计算机类', 'IMG_0037.JPG');
INSERT INTO `users_sr` VALUES ('36', '1', '1', '11', '1', '1', '已审核', '通过', '体育类', '1.jpg');
INSERT INTO `users_sr` VALUES ('37', '1', '333', '33', '33', '3', '已审核', '通过', '体育类', '1.jpg');
INSERT INTO `users_sr` VALUES ('41', '1', '2', '2', '2', '2', '待审核', '通过', '计算机类', '2.jpg');
INSERT INTO `users_sr` VALUES ('42', '1', '云计算', '工程', '1', '1', '已审核', '未通过', '计算机类', null);
INSERT INTO `users_sr` VALUES ('43', '10', '1', '1', '1', '1', '已审核', '通过', '体育类', 'biyesheji.sql');
INSERT INTO `users_sr` VALUES ('45', '1', '测试1', '测试1', '测试1', '测试1', '已审核', '通过', '体育类', 'IMG_0033.JPG');
INSERT INTO `users_sr` VALUES ('46', '1', '测试2', '测试2', '测试', '2', '已审核', '通过', '体育类', 'IMG_0037.JPG');
INSERT INTO `users_sr` VALUES ('47', '1', '0', '0', '0', '0', '已审核', '未通过', '体育类', 'IMG_0327.JPG');
INSERT INTO `users_sr` VALUES ('48', '1', '3', '3', '3', '3', '待审核', null, '体育类', '13区教材计划生费合计17-0502.xls');
INSERT INTO `users_sr` VALUES ('49', '1', '0', '0', '0', '0', '待审核', null, '体育类', null);
INSERT INTO `users_sr` VALUES ('50', '1', '0', '0', '0', '0', '待审核', null, '土木类', null);
INSERT INTO `users_sr` VALUES ('51', '1', '11', '11', '1111', '111', '待审核', null, '土木类', '2015秦汉史满分考试答案.doc');
INSERT INTO `users_sr` VALUES ('52', '1', '科研信息', '河南工程学院', '科研', '20173.31', '待审核', null, '体育类', null);

-- ----------------------------
-- View structure for v_users_sr
-- ----------------------------
DROP VIEW IF EXISTS `v_users_sr`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost`  VIEW `v_users_sr` AS select * from users_sr where sradopt = '通过' ;
