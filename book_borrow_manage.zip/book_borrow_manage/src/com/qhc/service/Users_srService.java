package com.qhc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qhc.bean.Admin;
import com.qhc.bean.Users;
import com.qhc.bean.Users_sr;
import com.qhc.dao.Users_srDao;

@Service
public class Users_srService {
		@Autowired
		private Users_srDao ud;
		@Autowired
		private AdminService as;
		
		public int insertUsers_srService(Users_sr users_sr){
			List<Users_sr> list = ud.selectUsers_srDao(users_sr);
			
			if(list.size()>0){
				
				return 0;
			}else{
				ud.insertUsers_srDao(users_sr);
				int i = ud.selectsridUsers_srDao(users_sr);
				return i;
			}
			
		}
		
		public List<Users_sr> selectUsers_srService(int userid){
			List<Users_sr> list = ud.selectUsers_srDao(userid);
			return list;
		}
		
		public List<Users_sr> adminselectUsers_srService(Admin admin,Users_sr users_ser){
			String adminsrtype = as.srtypeAdminService(admin);
			users_ser.setSrtype(adminsrtype);
			List<Users_sr> list = ud.adminselectUsers_srDao(users_ser);
			return list;
		}
		
		public List<Users_sr> adminselectUsers_srService(Users_sr users_ser){
			int i = ud.updateUsers_srDao(users_ser);
			List<Users_sr> list = ud.adminselectUsers_srDao(users_ser);
			return list;		
		}
		
		public boolean updateUsers_srService(Users_sr users_ser){
			int i = ud.updateUsers_srDao(users_ser);
			if(i>-1){
				return true;
			}else{
				return false;
			}
		}
		
		
		
		public List<Users_sr> likesridUsers_srService(Users_sr users_sr){
			List<Users_sr> list = ud.likesridUsers_srDao(users_sr);
			return list;
		}
		
		
		public List<Users_sr> likesrnameUsers_srService(Users_sr users_sr){
			List<Users_sr> list = ud.likesrnameUsers_srDao(users_sr);
			return list;
		}
		
		
		public List<Users_sr> likeuseridUsers_srService(Users_sr users_sr){
			List<Users_sr> list = ud.likeuseridUsers_srDao(users_sr);
			return list;
		}
		
		public List<Users_sr> listUsers_srService(){
			List<Users_sr> list = ud.listUsers_srDao();
			return list;
		}
		
		
		
		public boolean updatereportUsers_srDao(String report,int srid){
			int i = ud.updatereportUsers_srDao(report, srid);
			if(i>=0){
				return true;
			}else{
				return false;
			}
		}
		
		
		public List<Users_sr> chaxulikesrnameService(Users_sr users_sr){
			List<Users_sr> list = ud.chaxulikesrnameUsers_srDao(users_sr);
			return list;
		}
		
		
		public List<Users_sr> lookService(Users_sr users_sr){
			List<Users_sr> list = ud.adminselectUsers_srDao(users_sr);
			return list;
		}
		
		
		
}
