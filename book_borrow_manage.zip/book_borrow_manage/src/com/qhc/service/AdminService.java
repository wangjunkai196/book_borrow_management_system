package com.qhc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qhc.bean.Admin;
import com.qhc.bean.Users;
import com.qhc.bean.Users_sr;
import com.qhc.dao.AdminDao;

@Service
public class AdminService {
	
	@Autowired
	private AdminDao ad;
	
	public boolean loginAdminService(Admin admin){
		int i = ad.loginAdminDao(admin);
		if(i>0){
			return true;
		}else{
			return false;
		}
	}
	
	public List<Admin> selectAdminService(){
		List<Admin> list = ad.selectAdminDao();
		return list;
	}
	
	public void deleteAdminService(int adminid){
		ad.deleteAdminDao(adminid);
	}
	
	
	public boolean addAdminService(Admin admin){
		int i = ad.addAdminDao(admin);
		if(i>=0){
			return true;
		}else{
			return false;
		}
	}
	
	public boolean updateAdminService(Admin admin){
		int i = ad.updateAdminDao(admin);
		if(i>0){
			return true;
		}else{
			return false;
		}
	}
	
	public String srtypeAdminService(Admin admin){
		String s = ad.srtypeAdminDao(admin);
		return s;
	}
	
	
	public List<Admin> likenameAdminService(String adminname){
		List<Admin> list = ad.likenameAdminDao(adminname);
		return list;
	}
	
	
	public List<Admin> likeidAdminService(int adminid){
		List<Admin> list = ad.likeidAdminDao(adminid);
		return list;
	}
	
	
	
	public String telephoneAdminDao(String adminsrtype){
		String i = ad.telephoneAdminDao(adminsrtype);
		return i;
	}
	
	
	public String qitatelephoneAdminDao(){
		String i = ad.qitatelephoneAdminDao();
		return i;
	}
	
	public List<Admin> srtypeAdminService(){
		List<Admin> list =ad.srtypeAdminDao();
	return list;}
	
}
