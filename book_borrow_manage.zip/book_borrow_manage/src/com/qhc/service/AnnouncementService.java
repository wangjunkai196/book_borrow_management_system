package com.qhc.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qhc.bean.Announcement;
import com.qhc.dao.AnnouncementDao;

@Service
public class AnnouncementService {

	@Autowired
	private AnnouncementDao ad;
	
	public boolean addAnnouncementDao(Announcement announce){
		Date date = new Date();
        String nowTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(date);
        announce.setTime(nowTime);
		int i = ad.addAnnouncementDao(announce);
		if(i>=0){
			return true;
		}else{
			return false;
		}
	}
	
	
	public List<Announcement> selectAnnouncementDao(){
		List<Announcement> list = ad.selectAnnouncementDao();
		return list;
	}
	
	
	
	
}
