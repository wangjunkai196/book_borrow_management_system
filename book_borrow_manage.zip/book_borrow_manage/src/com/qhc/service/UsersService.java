package com.qhc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qhc.bean.Users;
import com.qhc.bean.Users_sr;
import com.qhc.dao.UsersDao;

@Service
public class UsersService {
	@Autowired
	private UsersDao ud;
	
	public List<Users> loginUsersService(Users users){
			List<Users> list = ud.loginUsersDao(users);
			return list;
		
	}
	
	

	
	public boolean insertUsersService(Users users){
		int i = ud.insertUsersDao(users);
		if(i>=0){
			return true;
		}else{
			return false;
		}
	}
	
	public String shensuUserService(Users users){
		String s = ud.shensuUsersDao(users);
		return s;
	}
	
	public boolean updateUsersService(Users users){
		int i = ud.updateUsersDao(users);
		if(i>-1){
			return true;
		}else{
			return false;
		}
	}
	
	
	public void headUsersDao(String head,int userid){
		ud.headUsersDao(head, userid);
	}
	
	
	
	public List<Users> selectUsersService(){
		List<Users> list = ud.selectUsersCon();
		return list;
		
	}
	
	
	public List<Users> likeuseridUsersDao(Users users){
		List<Users> list = ud.likeuseridUsersDao(users);
		
		return list;
	}

	
	public List<Users> likedegreeunitUsersDao(Users users){
		List<Users> list = ud.likedegreeunitUsersDao(users);
		
		return list;
	}
	
	
	public List<Users> likeusernameUsersDao(Users users){
		List<Users> list = ud.likeusernameUsersDao(users);
		
		return list;
	}
	
	public List<Users> likedegreeUsersDao(Users users){
		List<Users> list = ud.likedegreeUsersDao(users);
		
		return list;
	}
	
	public void deleteUsersService(int userid){
		ud.deleteUsersDao(userid);
	}
	
	
	public List<Users> selectuseridUsersService(int userid){
		List<Users> list = ud.selectuseridUsersDao(userid);
		return list;
	}
	
	
	
	
}
