package com.qhc.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.qhc.bean.Journal;
import com.qhc.bean.Users;


@Repository
public class JournalDao {
	@Autowired
	private SessionFactory sf;
	private Session session;
	
	public List<Journal> selectJournalDao(int userid){
		String hql = " from Journal as a where a.userid = ? ";
		session = sf.openSession();
		Query query = session.createQuery(hql);
		query.setInteger(0, userid);
		List<Journal> list = (List)query.list();
		session.close();
		return list;
	}
	
	
	
	public void addJournal(Journal journal){
		session = sf.openSession();
		Transaction tc = session.beginTransaction();
		try{
			session.save(journal);
			tc.commit();
			session.close();
		}catch(Exception e){
			tc.rollback();
			session.close();
		}
		
	}
	
	
	
	
	
	
	
	
	
}
