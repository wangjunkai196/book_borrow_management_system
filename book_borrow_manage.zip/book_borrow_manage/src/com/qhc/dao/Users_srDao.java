package com.qhc.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.qhc.bean.Admin;
import com.qhc.bean.Users;
import com.qhc.bean.Users_sr;

@Repository
public class Users_srDao {
	@Autowired
	private SessionFactory sf;
	private Session session;
	
	
	public int insertUsers_srDao(Users_sr Users_sr){
		session = sf.openSession();
		Transaction tc = session.beginTransaction();
		try{
			int i = (int)session.save(Users_sr);
			tc.commit();
			session.close();
			return i;
		}catch(Exception e){
			tc.rollback();
			session.close();
			return -1;
		}
		
	}
	
	
	

	public List<Users_sr> selectUsers_srDao(Users_sr users_sr){
		String sql = " from Users_sr where srname = ? and srunit = ? and srlist = ? and sradopt = ? ";
		session = sf.openSession();
		Query query = session.createQuery(sql);
		query.setString(0,users_sr.getSrname());
		query.setString(1,users_sr.getSrunit());
		query.setString(2,users_sr.getSrlist());
		query.setString(3, "通过");
		List<Users_sr> list = (List)query.list();
		session.close();
		return list;
	}
	
	
	
	
	public int selectsridUsers_srDao(Users_sr users_sr){
		String hql = " select srid from Users_sr where srname = ? and srunit = ? and srlist = ? and srcheck = ? ";
		session = sf.openSession();
		Query query = session.createQuery(hql);
		query.setString(0,users_sr.getSrname());
		query.setString(1,users_sr.getSrunit());
		query.setString(2,users_sr.getSrlist());
		query.setString(3, "待审核");
		Number number = (Number)query.uniqueResult();
		int i = number.intValue();
		session.close();
		return i;
	}
	
	
	
	
	
	public List<Users_sr> selectUsers_srDao(int userid){
		String hql = " from Users_sr as a where a.userid = ? ";
		session = sf.openSession();
		Query query = session.createQuery(hql);
		query.setInteger(0, userid);
		List<Users_sr> list = (List)query.list();
		session.close();
		return list;
	}
	
	
	public List<Users_sr> adminselectUsers_srDao(Users_sr users_ser){
		String hql = " select a from Users_sr as a where a.srtype = ? ";
		session = sf.openSession();
		Query query = session.createQuery(hql);
		query.setString(0, users_ser.getSrtype());
		List<Users_sr> list = (List)query.list();
		session.close();
		return list;
	}
	
	
	public int updateUsers_srDao(Users_sr users_ser){
		String hql = " update Users_sr set srcheck = ?,sradopt = ? where srid = ? ";
		session = sf.openSession();
		Query query = session.createQuery(hql);
		query.setString(0,"已审核");
		query.setString(1,users_ser.getSradopt());
		query.setInteger(2, users_ser.getSrid());
		Number number = (Number)query.executeUpdate();
		int i = number.intValue();
		session.close();
		return i;
	}
	
	
	public List<Users_sr> likesridUsers_srDao(Users_sr users_sr){
		String hql = " from Users_sr where srtype = ? and srid like ? ";
		session = sf.openSession();
		Query query = session.createQuery(hql);
		query.setString(0,users_sr.getSrtype());
		query.setString(1, "%"+users_sr.getSrid()+"%");
		List<Users_sr> list = (List)query.list();
		session.close();
		return list;
	}
	
	
	public List<Users_sr> likeuseridUsers_srDao(Users_sr users_sr){
		String hql = " from Users_sr where srtype = ? and userid like ? ";
		session = sf.openSession();
		Query query = session.createQuery(hql);
		query.setString(0,users_sr.getSrtype());
		query.setString(1, "%"+users_sr.getUserid()+"%");
		List<Users_sr> list = (List)query.list();
		session.close();
		return list;
	}
	
	
	public List<Users_sr> likesrnameUsers_srDao(Users_sr users_sr){
		String hql = " from Users_sr where srtype = ? and srname like ? ";
		session = sf.openSession();
		Query query = session.createQuery(hql);
		query.setString(0,users_sr.getSrtype());
		query.setString(1, "%"+users_sr.getSrname()+"%");
		List<Users_sr> list = (List)query.list();
		session.close();
		return list;
	}
	
	
	
	public List<Users_sr> listUsers_srDao(){
		String hql = " from Users_sr where sradopt = ? ";
		session = sf.openSession();
		Query query = session.createQuery(hql);
		query.setString(0, "通过");
		List<Users_sr> list = (List)query.list();
		session.close();
		return list;
	}
	
	
	
	public int updatereportUsers_srDao(String report,int srid){
		String hql = " update Users_sr set reportname = ? where srid = ? ";
		session = sf.openSession();
		Query query = session.createQuery(hql);
		query.setString(0,report);
		query.setInteger(1, srid);
		Number number = (Number)query.executeUpdate();
		int i = number.intValue();
		session.close();
		return i;
	}
	
	
	
	public List<Users_sr> chaxulikesrnameUsers_srDao(Users_sr users_sr){
		String hql = " from Users_sr where sradopt = ? and srname like ? ";
		session = sf.openSession();
		Query query = session.createQuery(hql);
		query.setString(0, "通过");
		query.setString(1, "%"+users_sr.getSrname()+"%");
		List<Users_sr> list = (List)query.list();
		session.close();
		return list;
	}
	
	
	
	
	
	
}
