package com.qhc.dao;

import java.util.List;

import javax.management.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.qhc.bean.Announcement;



@Repository
public class AnnouncementDao {
	@Autowired
	private SessionFactory sf;
	private Session session;
	
	
	public int addAnnouncementDao(Announcement announce){
		session = sf.openSession();
		Transaction tc = session.beginTransaction();
		try{
			int i = (int)session.save(announce);
			tc.commit();
			session.close();
			return i;
		}catch(Exception e){
			tc.rollback();
			session.close();
			return -1;
		}
		
	}
	
	
	public List<Announcement> selectAnnouncementDao(){
		String hql= " from  Announcement ";
		session = sf.openSession();
		List<Announcement> list= (List)session.createQuery(hql).list();
		session.close();
		return list;
	}
	
	
	
	
	
	
}
