package com.qhc.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.qhc.bean.Users;
import com.qhc.bean.Users_sr;

@Repository
public class UsersDao {
	@Autowired
	private SessionFactory sf;
	private Session session;
	
	public List<Users> loginUsersDao(Users users){
		String hql=" from Users u where u.username = ? and u.password = ? ";
		session = sf.openSession();
		Query query = session.createQuery(hql);
		query.setString(0, users.getUsername());
		query.setString(1, users.getPassword());
		List<Users> list = (List)query.list();
		session.close();
		return list;
	}
	

	
	
	public int insertUsersDao(Users users){
		session = sf.openSession();
		Transaction tc = session.beginTransaction();
		try{
			int i = (int)session.save(users);
			tc.commit();
			session.close();
			return i;
		}catch(Exception e){
			tc.rollback();
			session.close();
			return -1;
		}
		
	}
	
	
	public String shensuUsersDao(Users users){
		String hql = " select u.password from Users u where u.userid = ? and u.username = ? and u.email = ? ";
		session = sf.openSession();
		Query query = session.createQuery(hql);
		query.setInteger(0, users.getUserid());
		query.setString(1, users.getUsername());
		query.setString(2, users.getEmail());
		String s = (String)query.uniqueResult();
		session.close();
		return s;
	}
	
	
	public int updateUsersDao(Users users){
		String hql = " update Users set username = ?,password = ?,degree = ?,degree_unit = ?,degree_start = ?,degree_end = ?,degree_najor = ?,email = ? where userid = ? ";
		session = sf.openSession();
		Query query = session.createQuery(hql);
		query.setString(0,users.getUsername() );
		query.setString(1,users.getPassword());
		query.setString(2,users.getDegree() );
		query.setString(3,users.getDegree_unit() );
		query.setDate(4,users.getDegree_start() );
		query.setDate(5,users.getDegree_end() );
		query.setString(6,users.getDegree_najor() );
		query.setString(7,users.getEmail() );
		query.setInteger(8,users.getUserid() );
		Number number = (Number)query.executeUpdate();
		int i = number.intValue();
		session.close();
		return i;
	}
	
	
	
	public int headUsersDao(String head,int userid){
		String hql = " update Users set head = ? where userid = ? ";
		session = sf.openSession();
		Query query = session.createQuery(hql);
		query.setString(0,head);
		query.setInteger(1, userid);
		Number number = (Number)query.executeUpdate();
		int i = number.intValue();
		session.close();
		return i;
	}
	
	public List<Users> selectUsersCon(){
		String hql = " from Users ";
		session = sf.openSession();
		List<Users> list = (List)session.createQuery(hql).list();
		session.close();
		return list;
	}
	
	
	public List<Users> likeuseridUsersDao(Users users){
		String hql = " from Users where userid like ? ";
		session = sf.openSession();
		Query query = session.createQuery(hql);
		query.setString(0, "%"+users.getUserid()+"%");
		List<Users> list = (List)query.list();
		session.close();
		return list;
	}
	
	
	public List<Users> likedegreeunitUsersDao(Users users){
		String hql = " from Users where degree_unit like ? ";
		session = sf.openSession();
		Query query = session.createQuery(hql);
		query.setString(0, "%"+users.getDegree_unit()+"%");
		List<Users> list = (List)query.list();
		session.close();
		return list;
	}
	
	
	public List<Users> likeusernameUsersDao(Users users){
		String hql = " from Users where username like ? ";
		session = sf.openSession();
		Query query = session.createQuery(hql);
		query.setString(0, "%"+users.getUsername()+"%");
		List<Users> list = (List)query.list();
		session.close();
		return list;
	}
	
	public List<Users> likedegreeUsersDao(Users users){
		String hql = " from Users where degree like ? ";
		session = sf.openSession();
		Query query = session.createQuery(hql);
		query.setString(0, "%"+users.getDegree()+"%");
		List<Users> list = (List)query.list();
		session.close();
		return list;
	}
	
	
	
	
	public void deleteUsersDao(int userid){
		String hql = "delete from Users where userid = ?";
		session = sf.openSession();
		Query query = session.createQuery(hql);
		query.setInteger(0, userid);
		session.close();
		query.executeUpdate();
	}
	
	
	public List<Users> selectuseridUsersDao(int userid){
		String hql = " from Users where userid = ? ";
		session = sf.openSession();
		Query query  = session.createQuery(hql);
		query.setInteger(0, userid);
		List<Users> list = (List)query.list();
		session.close();
		return list;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
