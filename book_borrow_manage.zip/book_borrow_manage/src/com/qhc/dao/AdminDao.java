package com.qhc.dao;

import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.qhc.bean.Admin;
import com.qhc.bean.Users;
import com.qhc.bean.Users_sr;

@Repository
public class AdminDao {
	@Autowired
	private SessionFactory sf;
	private Session session;
	
	public int loginAdminDao(Admin admin){
		String hql=" select count(*) from Admin a where a.adminname = ? and a.adminpassword = ? ";
		session = sf.openSession();
		Query query = session.createQuery(hql);
		query.setString(0, admin.getAdminname());
		query.setString(1, admin.getAdminpassword());
		Number number = (Number)query.uniqueResult();
		int i = number.intValue();
		session.close();
		return i;
	}
	
	public List<Admin> selectAdminDao(){
		String hql = " select a from Admin as a ";
		session = sf.openSession();
		List<Admin> list = (List)session.createQuery(hql).list();
		session.close();
		return list;
	}
	
	public void deleteAdminDao(int adminid){
		String hql = "delete from Admin where adminid = ?";
		session = sf.openSession();
		Query query = session.createQuery(hql);
		query.setInteger(0, adminid);
		query.executeUpdate();
		session.close();
	}
	 
	public int addAdminDao(Admin admin){
		session = sf.openSession();
		Transaction tc = session.beginTransaction();
		try{
			int i = (int)session.save(admin);
			tc.commit();
			session.close();
			return i;
		}catch(Exception e){
			tc.rollback();
			session.close();
			return -1;
		}
		
	}
	
	
	public int updateAdminDao(Admin admin){
		String hql = " update Admin set adminname = ?,adminpassword = ?,adminsrtype = ?,telephone = ? where adminid = ? ";
		session = sf.openSession();
		Query query = session.createQuery(hql);
		query.setString(0, admin.getAdminname());
		query.setString(1, admin.getAdminpassword());
		query.setString(2, admin.getAdminsrtype());
		query.setString(3, admin.getTelephone());
		query.setInteger(4, admin.getAdminid());
		Number number = (Number)query.executeUpdate();
		int i = number.intValue();
		session.close();
		return i;
	}
	
	public String srtypeAdminDao(Admin admin){
		String hql = " select a.adminsrtype from Admin a where a.adminname = ? and a.adminpassword = ? ";
		session = sf.openSession();
		Query query = session.createQuery(hql);
		query.setString(0, admin.getAdminname());
		query.setString(1, admin.getAdminpassword());
		String s = (String)query.uniqueResult();
		session.close();
		return s;
	}
	
	
	public List<Admin> likenameAdminDao(String adminname){
		String hql = " from Admin where adminname like ? ";
		session = sf.openSession();
		Query query = session.createQuery(hql);
		query.setString(0, "%"+adminname+"%");
		List<Admin> list = (List)query.list();
		session.close();
		return list;
	}
	
	public List<Admin> likeidAdminDao(int adminid){
		String hql = " from Admin where adminid like ? ";
		session = sf.openSession();
		Query query = session.createQuery(hql);
		query.setString(0, "%"+adminid+"%");
		List<Admin> list = (List)query.list();
		session.close();
		return list;
	}
	
	
	
	public String telephoneAdminDao(String adminsrtype){
		String hql=" select a.telephone from Admin a where a.adminsrtype = ? ";
		session = sf.openSession();
		Query query = session.createQuery(hql);
		query.setString(0, adminsrtype);
		String i = (String)query.uniqueResult();
		session.close();
		return i;
	}
	
	
	
	
	
	public String qitatelephoneAdminDao(){
		String hql=" select a.telephone from Admin a where a.adminsrtype = ? ";
		session = sf.openSession();
		Query query = session.createQuery(hql);
		query.setString(0, "其他类");
		String i = (String)query.uniqueResult();
		session.close();
		return i;
	}
	
	public List<Admin> srtypeAdminDao(){
		String hql = " from Admin ";
		session = sf.openSession();
		Query query = session.createQuery(hql);
		List<Admin> list = (List)query.list();
		session.close();
		return list;
	}
	
	
}
