package com.qhc.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.qhc.bean.Announcement;
import com.qhc.service.AnnouncementService;

@Controller
public class AnnouncementController {

	@Autowired
	private AnnouncementService as;
	@Autowired 
	private HttpServletRequest request;
	
	@RequestMapping("/announce")
	public String addAnnouncementCon(Announcement announce){
		boolean b = as.addAnnouncementDao(announce);
		if(b){
			List<Announcement> list = as.selectAnnouncementDao();
			request.setAttribute("listif", 3);
			request.setAttribute("announcelist", list);
			request.setAttribute("announce", "发布成功!");
		}else{
			request.setAttribute("announce", "发布失败!");
		}
		return "zongguan";
	}
	
	
	@RequestMapping("/announcelist")
	public  String announcelistCon(){
		List<Announcement> list = as.selectAnnouncementDao();
		request.setAttribute("listif", 3);
		request.setAttribute("announcelist", list);
		return "zongguan";
	}
	
	
}
