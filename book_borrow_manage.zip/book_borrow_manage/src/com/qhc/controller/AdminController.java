package com.qhc.controller;


import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.qhc.bean.Admin;
import com.qhc.bean.Users;
import com.qhc.bean.Users_sr;
import com.qhc.service.AdminService;
import com.qhc.service.UsersService;
import com.qhc.service.Users_srService;

@Controller
public class AdminController {
	
	@Autowired
	private UsersService us;
	@Autowired
	private AdminService as;
	@Autowired
	private Users_srService uss;
	@Autowired 
	private HttpServletRequest request;
	
	@RequestMapping("/loginadmin")
	public String loginAdminCon(Admin admin,Users users,Users_sr users_ser){
		String juese = (String)request.getParameter("juese");
		String ivalcode = (String)request.getParameter("ivalcode");
		String valcode = (String)request.getSession().getAttribute("valcode");
		if(ivalcode.equals(valcode)){
			if(juese.equals("管理员")){
				boolean b = as.loginAdminService(admin);
				String name = admin.getAdminname();
				if(b){
					if(name.equals("覃华财")){
						List<Admin> list = as.selectAdminService();
						request.getSession().setAttribute("feifadenglu", 0);
						request.setAttribute("listif", 1);
						request.setAttribute("list", list);
						return "zongguan";
					}else{
						
						List<Users_sr> list = uss.adminselectUsers_srService(admin,users_ser);
						request.getSession().setAttribute("telephone", as.telephoneAdminDao("超级管理员"));
						request.setAttribute("listif", 1);
						request.setAttribute("list", list);
						request.getSession().setAttribute("srtype", as.srtypeAdminService(admin));
						return "admin";
					}
					
				}else{
					request.setAttribute("lg", "账号或密码错误！");
					return "login";
				}
			}else{
				users.setUsername(admin.getAdminname());
				users.setPassword(admin.getAdminpassword());
				List<Users> list = us.loginUsersService(users);
				if(list.isEmpty()){
					request.setAttribute("lg", "账号或密码错误！");
					return "login";
				}else{
					request.getSession().setAttribute("head", list.get(0).getHead());
					request.setAttribute("listif",1);
					request.getSession().setAttribute("user", list.get(0));
					request.setAttribute("userslist", list);
					return "users";
				}

			}
		}else{
			request.setAttribute("lg", "验证码错误");
			return "login";
		}
		
		
	}
	
	
	
	@RequestMapping("/admin")
	public String adminAdminCon(){
		List<Admin> list = as.selectAdminService();
		request.setAttribute("listif", 1);
		request.setAttribute("list", list);
		return "zongguan";
		
	}
	
	
	
	@RequestMapping("/delete/{adminid}")
	public String deleteAdminCon(@PathVariable int adminid){
		as.deleteAdminService(adminid);
		List<Admin> list = as.selectAdminService();
		request.setAttribute("listif", 1);
		request.setAttribute("list", list);
		return "zongguan";
	}
	
	
	@RequestMapping("/addadmin")
	public String addAdminCon(Admin admin){
		boolean b = as.addAdminService(admin);
		if(b){
			List<Admin> list = as.selectAdminService();
			request.setAttribute("listif", 1);
			request.setAttribute("list", list);
			request.setAttribute("add", "添加成功");
			return "zongguan";
		}else{
			request.setAttribute("listif", 1);
			request.setAttribute("add", "添加失败");
			return "zongguan";
		}
	}
	
	
	@RequestMapping("/updateadmin")
	public String updateAdminCon(Admin admin){
		boolean b = as.updateAdminService(admin);
		if(b){
			List<Admin> list = as.selectAdminService();
			request.setAttribute("listif", 1);
			request.setAttribute("list", list);
			request.setAttribute("updateadmin", "修改成功");
			return "zongguan";
		}else{
			request.setAttribute("listif", 1);
			request.setAttribute("updateadmin", "修改失败");
			return "zongguan";
		}
		
	}
	
	
	
	@RequestMapping("/users_sr")
	public String updateUsers_srCon(Users_sr users_ser){
			List<Users_sr> list = uss.adminselectUsers_srService(users_ser);
			request.setAttribute("listif", 1);
			request.setAttribute("list", list);
			return "admin";
		
	}
	
	
	@RequestMapping("/likename")
	public String likenameAdminCon(Admin admin){
		List<Admin> list = as.likenameAdminService(admin.getAdminname());
		request.setAttribute("listif",1);
		request.setAttribute("list", list);
		return "zongguan";
	}
	
	@RequestMapping("/likeid")
	public String likeidAdminCon(Admin admin){
		List<Admin> list = as.likeidAdminService(admin.getAdminid());
		request.setAttribute("listif",1);
		request.setAttribute("list", list);
		return "zongguan";
	}
	
	@RequestMapping("/look")
	public String lookAdminCon(Users_sr users_sr){
		List<Users_sr> list = uss.lookService(users_sr);
		request.setAttribute("list", list);
		request.setAttribute("listif", 1);
		return "admin";
	}
	
	
	@RequestMapping("/exit")
	public String exit(){
		request.getSession().invalidate();
		return "redirect:/jsp/login.jsp";
	}
	

	
}
