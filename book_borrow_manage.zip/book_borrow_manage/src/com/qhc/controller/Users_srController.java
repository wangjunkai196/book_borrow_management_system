package com.qhc.controller;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.qhc.bean.Announcement;
import com.qhc.bean.Journal;
import com.qhc.bean.Users;
import com.qhc.bean.Users_sr;
import com.qhc.service.AdminService;
import com.qhc.service.AnnouncementService;
import com.qhc.service.JournalService;
import com.qhc.service.Users_srService;

@Controller
public class Users_srController {
		@Autowired
		private Users_srService us;
		@Autowired 
		private HttpServletRequest request;
		@Autowired
		private AdminService as;
		@Autowired
		private JournalService js;
		@Autowired
		private AnnouncementService announces;
		
		
		
		@RequestMapping("/up")
		public String insertUsers_srCon(Users_sr users_sr,Journal journal){
			Users list = (Users)request.getSession().getAttribute("user");
			String url = (String)request.getParameter("url");
			journal.setJournal(url);		
			journal.setUserid(list.getUserid());
			js.addJournal(journal);
			int i = us.insertUsers_srService(users_sr);
			if(i>0){
				request.setAttribute("srid", i);
				request.setAttribute("up", "提交成功，请上传您的论文！");
				return "up";
			}else{
				request.setAttribute("up", "提交失败，该论文已存在！");
				return "up";
			}
		}
		
		@RequestMapping("/users_sr/{userid}")
		public String selectUsers_srCon(@PathVariable int userid){
			List<Users_sr> users_srlist = us.selectUsers_srService(userid);
			String telephone ;
			if(users_srlist.isEmpty()){
				telephone = as.qitatelephoneAdminDao();
			}else{
				telephone = as.telephoneAdminDao(users_srlist.get(0).getSrtype());
				
			}
			request.setAttribute("telephone",telephone );
			request.setAttribute("listif",2);
			request.setAttribute("list", users_srlist);
			return "users";
			
		}
		
		
		@RequestMapping("/likesrid")
		public String likeidUsers_srCon(Users_sr users_sr){
			List<Users_sr> list = us.likesridUsers_srService(users_sr);
			request.setAttribute("listif",1);
			request.setAttribute("list", list);
			return "admin";
		}
		
		
		@RequestMapping("/likeuserid")
		public String likeuseridUsers_srCon(Users_sr users_sr){
			List<Users_sr> list = us.likeuseridUsers_srService(users_sr);
			request.setAttribute("listif",1);
			request.setAttribute("list", list);
			return "admin";
		}
		
		@RequestMapping("/likesrname")
		public String likesrnameUsers_srCon(Users_sr users_sr){
			List<Users_sr> list = us.likesrnameUsers_srService(users_sr);
			request.setAttribute("listif",1);
			request.setAttribute("list", list);
			return "admin";
		}
		
		
		@RequestMapping("/users_srlist")
		public String listUsers_srCon(){
			List<Announcement> announcelist = announces.selectAnnouncementDao();
			List<Users_sr> userslist = us.listUsers_srService();
			request.setAttribute("users_srlist", userslist);
			request.setAttribute("announcelist", announcelist);
			return "login";
		} 
		
		@RequestMapping("/uptext")
		public String updownCon(@RequestParam("file") CommonsMultipartFile[] files,HttpServletRequest request,Journal journal,Users_sr users_sr ){
			Users list = (Users)request.getSession().getAttribute("user");
			String url = (String)request.getParameter("url");
			journal.setJournal(url);		
			journal.setUserid(list.getUserid());
			js.addJournal(journal);
			String path = request.getServletContext().getRealPath("/")+"images/";
			for(MultipartFile filename:files){
				try {
					filename.transferTo(new File("E:/up/"+filename.getOriginalFilename()));
					us.updatereportUsers_srDao(filename.getOriginalFilename(), users_sr.getSrid());
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			request.setAttribute("uptext", "上传成功");
			return "up";
		}
		
		
		
		
		
		@RequestMapping("/down")
		public ResponseEntity<byte[]> downCon(@RequestParam("id") String id,HttpServletRequest request) throws IOException{
			String path = "E:/up/";
			String downname = path+id;
			File filename = new File(downname);
			String downname_china = new String(id.getBytes("utf-8"),"iso8859-1");
			HttpHeaders hh = new HttpHeaders();
			hh.setContentDispositionFormData("attachment", downname_china);
			hh.setContentType(MediaType.APPLICATION_OCTET_STREAM);
			return new ResponseEntity<byte[]>(FileUtils.readFileToByteArray(filename),hh,HttpStatus.CREATED);
		}
		
		
		
		
		@RequestMapping("/chaxulikesrname")
		public String chaxulikesrnameUsers_srCon(Users_sr users_sr){
			List<Users_sr> list = us.chaxulikesrnameService(users_sr);
			request.setAttribute("users_srlist", list);
			return "login";
		}
		
		
}
