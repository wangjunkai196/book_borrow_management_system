package com.qhc.controller;

import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.qhc.bean.Admin;
import com.qhc.bean.Journal;
import com.qhc.bean.Users;
import com.qhc.bean.Users_sr;
import com.qhc.service.AdminService;
import com.qhc.service.JournalService;
import com.qhc.service.UsersService;

@Controller
public class UsersController {
	
	@Autowired
	private UsersService us;
	@Autowired 
	private HttpServletRequest request;
	@Autowired
	private JournalService js;
	@Autowired
	private AdminService as;
	
	@RequestMapping("/users/{userid}")
	public String selectUsersCon(@PathVariable int userid,Journal journal){
		
		List<Users> list = us.selectuseridUsersService(userid);
		request.setAttribute("userslist", list);
		request.setAttribute("listif",1);
		return "users";
	}
	
	
	@RequestMapping("/zhuce")
	public String insertUsersCon(Users users) throws ParseException{
		String start = (String)request.getParameter("degree_startyear")+"-"+request.getParameter("degree_startmonth");
		String end = (String)request.getParameter("degree_endyear")+"-"+request.getParameter("degree_endmonth");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM");  
	    Date startdate = sdf.parse(start);
	    Date enddate = sdf.parse(end);
	    users.setDegree_start(startdate);
	    users.setDegree_end(enddate);
	    List<Users> list =us.loginUsersService(users);
	    if(list.isEmpty()){
	    	boolean b = us.insertUsersService(users);
			if(b){
				request.setAttribute("zhuce", "注册成功");
				return "zhuce";
			}else{
				request.setAttribute("zhuce", "注册失败");
				return "zhuce";
			}
	    	
	}
	else{
		request.setAttribute("zhuce", "用户已存在");
	return "zhuce";
		
	}
	
	}
	
	@RequestMapping("/shensu")
	public String shensuUsersCon(Users users){
		String s = us.shensuUserService(users);
		if(null==s){
			request.setAttribute("shensu","申诉失败,申诉信息不正确！");
		}else{
			request.setAttribute("shensu","申诉成功，您的密码是："+s);
		}
		return "shensu";
	}
	
	@RequestMapping("/updateusers")
	public String updateUsersCon(Users users,Journal journal) throws ParseException{
		Users list = (Users)request.getSession().getAttribute("user");
		String url = (String)request.getParameter("url");
		journal.setJournal(url);		
		journal.setUserid(list.getUserid());
		js.addJournal(journal);
		String start = (String)request.getParameter("degree_startyear")+"-"+request.getParameter("degree_startmonth");
		String end = (String)request.getParameter("degree_endyear")+"-"+request.getParameter("degree_endmonth");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM");  
	    Date startdate = sdf.parse(start);
	    Date enddate = sdf.parse(end);
	    users.setDegree_start(startdate);
	    users.setDegree_end(enddate);
		boolean b = us.updateUsersService(users);
		if(b){
			List<Users> list1 = us.selectuseridUsersService(users.getUserid());
			request.setAttribute("userslist", list1);
			request.setAttribute("listif",1);
			request.setAttribute("updateusers", "修改成功");
			return "users";
		}else{
			request.setAttribute("updateusers", "修改失败");
			return "updateusers";
		}
		
	}
	
	
	@RequestMapping("/uphead")
	public String updownCon(@RequestParam("file") CommonsMultipartFile[] files,HttpServletRequest request,Journal journal,Users_sr users_sr ){
		String path = request.getServletContext().getRealPath("/")+"images/";
		
		Users list = (Users)request.getSession().getAttribute("user");
		for(MultipartFile filename:files){
			try {
				filename.transferTo(new File(path+filename.getOriginalFilename()));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			us.headUsersDao(filename.getOriginalFilename(), list.getUserid());
			request.getSession().setAttribute("head", filename.getOriginalFilename());
			List<Users> lis = us.selectuseridUsersService(list.getUserid());
			request.setAttribute("userslist", lis);
			request.setAttribute("listif",1);
		}
		
		return "users";
	}
	
	
	@RequestMapping("users")
	public String usersUsersCon(){
		List<Users> list = us.selectUsersService();
		request.setAttribute("listif", 2);
		request.setAttribute("list", list);
		return "zongguan";
		
	}
	
	
	
	@RequestMapping("/likeusersid")
	public String likeidUsersCon(Users users){
		List<Users> list = us.likeuseridUsersDao(users);
		request.setAttribute("listif", 2);
		request.setAttribute("list", list);
		return "zongguan";
	}
	
	
	@RequestMapping("/likeusername")
	public String likenameUsersCon(Users users){
		List<Users> list = us.likeusernameUsersDao(users);
		request.setAttribute("listif", 2);
		request.setAttribute("list", list);
		return "zongguan";
	}
	
	@RequestMapping("/likedegree")
	public String likedegreeUsersCon(Users users){
		List<Users> list = us.likedegreeUsersDao(users);
		request.setAttribute("listif", 2);
		request.setAttribute("list", list);
		return "zongguan";
	}
	
	@RequestMapping("/likedegreeunit")
	public String likedegreeunitUsersCon(Users users){
		List<Users> list = us.likedegreeunitUsersDao(users);
		request.setAttribute("listif", 2);
		request.setAttribute("list", list);
		return "zongguan";
	}
	
	@RequestMapping("/deleteuserid/{userid}")
	public String deleteUserCon(@PathVariable int userid){
		us.deleteUsersService(userid);
		List<Users> list = us.selectUsersService();
		request.setAttribute("listif", 2);
		request.setAttribute("list", list);
		return "zongguan";
		
	}
	
	@RequestMapping("/admin/{userid}")
	public String selectUsersCon(@PathVariable int userid){
		List<Users> list =us.selectuseridUsersService(userid);
		request.setAttribute("userlist",list);
		request.setAttribute("listif",2);
		return "admin";
	}
	

	
	
	@RequestMapping("/upuser")
	public String srtypeAdminCon(){
		
		List<Admin> list =as.srtypeAdminService();
		request.getSession().setAttribute("srtypeadmin", list);
		return "up";
	}
	
	
	
	
	
}
