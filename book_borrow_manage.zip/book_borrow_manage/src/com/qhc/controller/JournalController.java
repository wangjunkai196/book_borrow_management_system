package com.qhc.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;


import com.qhc.bean.Journal;
import com.qhc.service.JournalService;

@Controller
public class JournalController {
	
	@Autowired
	private JournalService js;
	@Autowired 
	private HttpServletRequest request;
	
	
	@RequestMapping("/journal/{userid}")
	public  String selectJournalService(@PathVariable int userid){
		List<Journal> journallist = js.selectJournalService(userid);
		request.setAttribute("listif",3);
		request.setAttribute("list", journallist);
		return "users";
	}
}
