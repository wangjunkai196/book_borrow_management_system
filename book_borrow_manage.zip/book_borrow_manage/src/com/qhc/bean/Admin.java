package com.qhc.bean;

public class Admin {

	private int adminid;
	private String adminname;
	private String adminpassword;
	private String adminsrtype;
	private String telephone;
	
	public int getAdminid() {
		return adminid;
	}
	public void setAdminid(int adminid) {
		this.adminid = adminid;
	}
	public String getAdminname() {
		return adminname;
	}
	public void setAdminname(String adminname) {
		this.adminname = adminname;
	}
	public String getAdminpassword() {
		return adminpassword;
	}
	public void setAdminpassword(String adminpassword) {
		this.adminpassword = adminpassword;
	}
	public String getAdminsrtype() {
		return adminsrtype;
	}
	public void setAdminsrtype(String adminsrtype) {
		this.adminsrtype = adminsrtype;
	}
	public String getTelephone() {
		return telephone;
	}
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	public Admin(int adminid, String adminname, String adminpassword, String adminsrtype, String telephone) {
		super();
		this.adminid = adminid;
		this.adminname = adminname;
		this.adminpassword = adminpassword;
		this.adminsrtype = adminsrtype;
		this.telephone = telephone;
	}
	public Admin() {
		super();
	}
	

	
	
	
}
