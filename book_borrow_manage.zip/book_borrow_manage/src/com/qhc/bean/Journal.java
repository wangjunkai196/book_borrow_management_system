package com.qhc.bean;

public class Journal {

	private int journalid;
	private int userid;
	private String journal;
	private String journal_time;
	public int getJournalid() {
		return journalid;
	}
	public void setJournalid(int journalid) {
		this.journalid = journalid;
	}
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public String getJournal() {
		return journal;
	}
	public void setJournal(String journal) {
		this.journal = journal;
	}
	public String getJournal_time() {
		return journal_time;
	}
	public void setJournal_time(String journal_time) {
		this.journal_time = journal_time;
	}
	public Journal(int journalid, int userid, String journal, String journal_time) {
		super();
		this.journalid = journalid;
		this.userid = userid;
		this.journal = journal;
		this.journal_time = journal_time;
	}
	public Journal() {
		super();
	}
	
	
	
	
	
}
