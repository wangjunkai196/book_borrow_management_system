package com.qhc.bean;

public class Announcement {
	
	private int id;
	private String announcement;
	private String time;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAnnouncement() {
		return announcement;
	}
	public void setAnnouncement(String announcement) {
		this.announcement = announcement;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public Announcement(int id, String announcement, String time) {
		super();
		this.id = id;
		this.announcement = announcement;
		this.time = time;
	}
	public Announcement() {
		super();
	}
	
	
	
	
	
	
}
