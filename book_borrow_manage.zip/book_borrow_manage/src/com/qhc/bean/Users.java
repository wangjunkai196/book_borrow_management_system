package com.qhc.bean;

import java.util.Date;

public class Users {
	private int userid;
	private String username;
	private String password;
	private String degree;
	private String degree_unit;
	private Date degree_start;
	private Date degree_end;
	private String degree_najor;
	private String email;
	private String head;
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getDegree() {
		return degree;
	}
	public void setDegree(String degree) {
		this.degree = degree;
	}
	public String getDegree_unit() {
		return degree_unit;
	}
	public void setDegree_unit(String degree_unit) {
		this.degree_unit = degree_unit;
	}
	public Date getDegree_start() {
		return degree_start;
	}
	public void setDegree_start(Date degree_start) {
		this.degree_start = degree_start;
	}
	public Date getDegree_end() {
		return degree_end;
	}
	public void setDegree_end(Date degree_end) {
		this.degree_end = degree_end;
	}
	public String getDegree_najor() {
		return degree_najor;
	}
	public void setDegree_najor(String degree_najor) {
		this.degree_najor = degree_najor;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getHead() {
		return head;
	}
	public void setHead(String head) {
		this.head = head;
	}
	public Users(int userid, String username, String password, String degree, String degree_unit, Date degree_start,
			Date degree_end, String degree_najor, String email, String head) {
		super();
		this.userid = userid;
		this.username = username;
		this.password = password;
		this.degree = degree;
		this.degree_unit = degree_unit;
		this.degree_start = degree_start;
		this.degree_end = degree_end;
		this.degree_najor = degree_najor;
		this.email = email;
		this.head = head;
	}
	public Users() {
		super();
	}


	


}


