package com.qhc.bean;

import java.util.Date;

public class Users_sr {

	private int srid;
	private int userid;
	private String srname;
	private String srunit;
	private String srlist;
	private String srtime;
	private String srcheck;
	private String srtype;
	private String sradopt;
	private String reportname;

	public int getSrid() {
		return srid;
	}
	public void setSrid(int srid) {
		this.srid = srid;
	}
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public String getSrname() {
		return srname;
	}
	public void setSrname(String srname) {
		this.srname = srname;
	}
	public String getSrunit() {
		return srunit;
	}
	public void setSrunit(String srunit) {
		this.srunit = srunit;
	}
	public String getSrlist() {
		return srlist;
	}
	public void setSrlist(String srlist) {
		this.srlist = srlist;
	}
	public String getSrtime() {
		return srtime;
	}
	public void setSrtime(String srtime) {
		this.srtime = srtime;
	}
	public String getSrcheck() {
		return srcheck;
	}
	public void setSrcheck(String srcheck) {
		this.srcheck = srcheck;
	}
	public String getSrtype() {
		return srtype;
	}
	public void setSrtype(String srtype) {
		this.srtype = srtype;
	}
	public String getSradopt() {
		return sradopt;
	}
	public void setSradopt(String sradopt) {
		this.sradopt = sradopt;
	}
	public String getReportname() {
		return reportname;
	}
	public void setReportname(String reportname) {
		this.reportname = reportname;
	}
	public Users_sr(int srid, int userid, String srname, String srunit, String srlist, String srtime, String srcheck,
			String srtype, String sradopt, String reportname) {
		super();
		this.srid = srid;
		this.userid = userid;
		this.srname = srname;
		this.srunit = srunit;
		this.srlist = srlist;
		this.srtime = srtime;
		this.srcheck = srcheck;
		this.srtype = srtype;
		this.sradopt = sradopt;
		this.reportname = reportname;
		
	}
	public Users_sr() {
		super();
	}
	
	
	
}
